class LaPanicException(Exception):
    pass

from enum import Enum


class BugType(Enum):
    FORCE_RESET = "151"
    FULL = "210"
